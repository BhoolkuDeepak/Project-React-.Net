public class Member
{
    public int MemberId { get; set; }
    public string Name { get; set; }
    public string Contact { get; set; }
}
