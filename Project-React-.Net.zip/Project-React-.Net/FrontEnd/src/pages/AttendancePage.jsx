import MarkAttendance from "../components/MarkAttendance";

function AttendancePage() {
  return <MarkAttendance />;
}

export default AttendancePage;
