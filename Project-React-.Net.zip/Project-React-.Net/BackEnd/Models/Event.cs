public class Event
{
    public int EventId { get; set; }
    public string EventName { get; set; }
    public string Timings { get; set; }
    public string Location { get; set; }
    public bool IsRecurring { get; set; }
    public string RecurringDay { get; set; }
    //public DateTime EventDate { get; set; } 
}
